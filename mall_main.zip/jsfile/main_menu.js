$(" #kor_book ").click(function () {
  $(" #s-d ").toggleClass('show');
})
$(" #eng_book ").click(function () {
  $(" #s-d2 ").toggleClass('show');
})
$(" #goods_book ").click(function () {
  $(" #s-d3 ").toggleClass('show');
})
$(" #login_space ").click(function () {
  $(" #s-d4 ").toggleClass('show');
})